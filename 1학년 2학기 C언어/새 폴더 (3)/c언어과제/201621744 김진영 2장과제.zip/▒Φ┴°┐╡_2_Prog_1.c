#include <stdio.h>

int main(void)
{
	printf("Hello/nC/nProgrammers!/n");
	return 0;
}