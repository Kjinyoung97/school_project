#include <stdio.h>

int main(void)
{
	printf("��\t��\tȭ\t��\t��\t��\t��\n");
	printf("1\t2\t3\t4\t5\t6\t7\n");
	printf("8\t9\t10\t11\t12\t13\t14\n");
	printf("15\t16\t17\t18\t19\t20\t21\n");
	printf("22\t23\t24\t25\t26\t27\t28\n");
	printf("29\t30\t31\n");
	return 0;
}