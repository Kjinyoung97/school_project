#include <stdio.h>

int main(void)
{
	printf("\a�߷η�.\n");

	return 0;
}